import {Col, Container, Row, Button, Form, Table} from 'react-bootstrap';
import {useState} from 'react';

function AnswerForm(props) {
    const [text, setText] = useState('');
    const [respondent, setRespondent] = useState('Graziano');
    const [score, setScore] = useState('');

    function handleSubmit(event) {
        event.preventDefault();

    }

    function handleRespondent(event) {
        const v = event.target.value;
        setRespondent(v.toUpperCase());
    }

    const handleScore = (event) => {
        const v = parseInt(event.target.value);
        if(!isNaN(v))
            setScore(v);
        else
            setScore('');
    }

    return (<Form onSubmit={handleSubmit}>
        <Form.Group>
            <Form.Label>Date</Form.Label>
            <Form.Control className="w-25" type="date" name="date"/>
        </Form.Group>
        <Form.Group>
            <Form.Label>Text</Form.Label>
            <Form.Control onChange={(event) => setText(event.target.value) } className="w-25" type="text" name="text" value={text}/>
        </Form.Group>
        <Form.Group>
            <Form.Label>Respondent</Form.Label>
            <Form.Control onChange={handleRespondent} className="w-25" type="text" name="respondent" value={respondent}/>
        </Form.Group>
        <Form.Group>
            <Form.Label>Score</Form.Label>
            <Form.Control onChange={handleScore} className="w-25" type="text" name="score" value={score}/>
        </Form.Group>
        <Button type="submit" variant="primary">Add</Button>
    </Form>);
}

export default AnswerForm

